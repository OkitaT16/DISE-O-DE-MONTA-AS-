
var contenedor = document.querySelector("#contenedor");
var ampliarLienzo = document.querySelector("#lienzo");
var btnAmpliar = document.querySelector("#btnAmpliar");


var canvas = document.querySelector("#lienzo");
var ctx = canvas.getContext("2d");

function dibujarPaisaje() {
    var grd = ctx.createLinearGradient(0, 0, 0, 500);
    grd.addColorStop(0, "rgba(0,0,255,0.5)");
    grd.addColorStop(1, "white");
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, 1000, 600);  
 

var grd2 = ctx.createLinearGradient(0, 400, 0, 500);
grd2.addColorStop(0, "rgba(0,180,255,0.5)");
grd2.addColorStop(1, "white");
ctx.fillStyle = grd2;
ctx.fillRect(0, 400, 1000, 100);


ctx.beginPath();
ctx.fillStyle = 'rgb(83, 75, 73)';
ctx.moveTo(0, 400);
ctx.lineTo(200, 100);
ctx.lineTo(400, 400);
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgb(83, 75, 73)';
ctx.moveTo(200, 400);
ctx.lineTo(400, 100);
ctx.lineTo(600, 400);
ctx.fill();


ctx.beginPath();
ctx.fillStyle = 'rgb(83, 75, 73)';
ctx.moveTo(400, 400);
ctx.lineTo(600, 100);
ctx.lineTo(800, 400);
ctx.fill();


ctx.beginPath();
ctx.fillStyle = 'rgb(83, 75, 73)';
ctx.moveTo(600, 400);
ctx.lineTo(800, 100);
ctx.lineTo(1000, 400);
ctx.fill();


ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(200, 300);
ctx.lineTo(200, 100);
ctx.lineTo(267, 200);
ctx.fill();


ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(333, 200);
ctx.lineTo(400, 100);
ctx.lineTo(400, 300);
ctx.fill();


ctx.beginPath();
ctx.fillStyle = 'rgba(104, 101, 100, 0.62)';
ctx.moveTo(200, 300);    
ctx.lineTo(400, 400);    
ctx.lineTo(200, 450	);    
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(99, 77, 60, 0.86)';
ctx.moveTo(200, 300);    
ctx.lineTo(0, 400);      
ctx.lineTo(200, 450);   
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(99, 77, 60, 0.86)';
ctx.moveTo(800, 300);    
ctx.lineTo(600, 400);     
ctx.lineTo(800, 450);     
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(104, 101, 100, 0.62)';
ctx.moveTo(800, 300);     
ctx.lineTo(1000, 400);    
ctx.lineTo(800, 450);     
ctx.fill();






ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(200, 300);
ctx.lineTo(200, 100);
ctx.lineTo(267, 200);
ctx.fill();


ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(133, 200);
ctx.lineTo(200, 100);
ctx.lineTo(200, 300);
ctx.fill();



ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(400, 300);
ctx.lineTo(400, 100);
ctx.lineTo(467, 200);
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(600, 300);
ctx.lineTo(600, 100);
ctx.lineTo(667, 200);
ctx.fill();


ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(533, 200);
ctx.lineTo(600, 100);
ctx.lineTo(600, 300);
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(800, 300);   
ctx.lineTo(800, 100);    
ctx.lineTo(867, 200);     
ctx.fill();

ctx.beginPath();
ctx.fillStyle = 'rgba(255,255,255,1)';
ctx.moveTo(733, 200);     
ctx.lineTo(800, 100);    
ctx.lineTo(800, 300);     
ctx.fill();


ctx.beginPath();
ctx.fillStyle = "#00cc00"; 
ctx.arc(0, 500, 250, 0, Math.PI * 2);
ctx.fill();

ctx.beginPath();
ctx.fillStyle = "#006600"; 
ctx.arc(1000, 500, 250, 0, Math.PI * 2);
ctx.fill();


// Tronco
ctx.fillStyle = 'rgb(143, 87, 62)';
ctx.fillRect(100, 300, 10, 50);

// Copas
ctx.fillStyle = 'rgb(36, 126, 8)';
ctx.beginPath(); ctx.arc(105, 290, 20, 0, Math.PI * 2); ctx.fill();

ctx.fillStyle = "#004d00";
ctx.beginPath(); ctx.arc(90, 280, 20, 0, Math.PI * 2); ctx.fill();

ctx.fillStyle = "#003300";
ctx.beginPath(); ctx.arc(120, 280, 20, 0, Math.PI * 2); ctx.fill();

ctx.fillStyle = 'rgb(117, 96, 67)';
ctx.fillRect(900, 300, 10, 50);

ctx.fillStyle = 'rgb(51, 142, 12)';
ctx.beginPath(); ctx.moveTo(905, 250); ctx.lineTo(875, 300); ctx.lineTo(935, 300); ctx.fill();

ctx.fillStyle = "#004d00";
ctx.beginPath(); ctx.moveTo(905, 230); ctx.lineTo(880, 270); ctx.lineTo(930, 270); ctx.fill();

ctx.fillStyle = "#003300";
ctx.beginPath(); ctx.moveTo(905, 210); ctx.lineTo(885, 240); ctx.lineTo(925, 240); ctx.fill();

for (let i = 0; i < 7; i++) {
  ctx.beginPath();
  ctx.fillStyle = "#006600";
  ctx.arc(30 + i * 30, 500, 15, 0, Math.PI * 2);
  ctx.fill();
}

}




function ampliar() {
    contenedor.style.width = "100%";
    contenedor.style.height = "100vh";
    contenedor.style.margin = "0";

    ampliarLienzo.style.width = "100%";
    ampliarLienzo.style.height = "100vh";
    ampliarLienzo.style.backgroundSize = "cover";
    ampliarLienzo.style.backgroundRepeat = "no-repeat";

    
    ampliarLienzo.width = window.innerWidth;
    ampliarLienzo.height = window.innerHeight;

    btnAmpliar.innerHTML = "Reducir Canvas";
    btnAmpliar.style.position = "fixed";
    btnAmpliar.style.top = "10px";
    btnAmpliar.style.left = "10px";
    btnAmpliar.style.zIndex = "1";

    btnAmpliar.setAttribute("onClick", "reducir()");

    dibujarPaisaje();
}


function reducir() {
    contenedor.style.width = "1000px";
    contenedor.style.height = "500px";
    contenedor.style.margin = "5vh auto";

    ampliarLienzo.style.width = "1000px";
    ampliarLienzo.style.height = "500px";

    ampliarLienzo.width = 1000;
    ampliarLienzo.height = 500;

    btnAmpliar.innerHTML = "Ampliar Canvas";
    btnAmpliar.style.position = "relative";
    btnAmpliar.style.top = "0";
    btnAmpliar.style.left = "0";
    btnAmpliar.style.zIndex = "0";

    btnAmpliar.setAttribute("onClick", "ampliar()");

    dibujarPaisaje();
}


dibujarPaisaje();
